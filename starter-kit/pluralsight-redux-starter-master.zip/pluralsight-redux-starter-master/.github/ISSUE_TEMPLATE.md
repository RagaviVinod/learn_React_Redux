# Wait, try this first...
Before opening an issue, [please try these things first](https://github.com/coryhouse/pluralsight-redux-starter#having-issues-try-these-things-first).

If that list doesn't help you fix the problem, fill out the info below.

Node version:

npm version:

Operating system:

Command line used:

Steps to reproduce:
